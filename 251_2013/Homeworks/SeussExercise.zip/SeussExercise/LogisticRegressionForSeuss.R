## To execute any commmand, highlight it with the mouse and hit Control r.

##########################################################################
## Load the necessary libraries.
##########################################################################

##If your computer doesn't have these, go to the Packages menu, pick a CRAN mirror site
##and download the necessary "packages"; i.e. languageR and arm.
##Then run these commands, as above, to get them into your computer's memory.

library(languageR)
library(arm)
 
##########################################################################
## Deal with your data file
##########################################################################

## You want a plain-text input file where all the columns are labeled, and the separator of columns is
## a tab.  

##CAUTION:  column headers should be extremely plain; it's best to use nothing but letters (you can
##  also use noninitial digits.  
##CAUTION:  R is case-sensitive; always check variable names with care.
##CAUTION:  apostrophes anywhere in your file will create chaos; remove or replace them before proceeding.

## Here is the command to read a data file.  Of course, you have to change it to match the file you have.
## sep="t" is needed so that it will assume that tab is the column separator.

MyData=read.table("SeussViolationsFile.txt", header=T, sep="\t")

   ##You can look at the column names with this command:
      colnames(MyData)

   ## You can use this command to check the content of the first few lines.  Add n = number to get a different number of lines.
      head(MyData)
   ## If you're having trouble, the following is useful for debugging bad input files -- it makes a printout of what R thinks 
   ## it's working with.
      write.table(MyData, file = "Debug.txt", sep="\t")

##########################################################################
## Eyeballing your data with contingency tables
##########################################################################

## This command gives you a list of all the variables you have available from your file to work with -- i.e. the column headers.
colnames(MyData)

## Contingency tables.
## Put the dependent variable first.
## In the schema, Line 1 performs the calculation, Line 2 gives raw counts, Line 3 the proportions, and Line 4 the chi-square.

## I really need to learn how to do this with all of the variables at once.

## ALWAYS DO THIS FIRST.
attach(MyData)

## Dependent variable with one independent variable.  The code further down creates a graph.
writeLines("") 
MyTable = xtabs( ~ IsSeuss + InitialZ)
MyTable
round(prop.table(MyTable), digits = 3)
summary(MyTable)

##This makes a table with the relative proportions.
PropTable = prop.table(MyTable, 2)
round(PropTable, digits=3)
ftable(PropTable)
barplot(PropTable)

##########################################################################
## Logistic regression
##########################################################################

## Here is how you set up the logistic regression model.

## For linguistics, the best r function for logistic regression is probably bayesglm().
## This is because there are often exceptionless principles--
##   you don't want the weights to go sky high without good justification.
##   bayesglm() employs a prior to enforce this principle
## The reference source for bayesglm() is http://www.stat.columbia.edu/~gelman/research/unpublished/priors7.pdf.
## If you want, you can leave the word "bayes" in this command and get classical glm instead.

MyModel = bayesglm(IsSeuss ~ +  
InitialZ +  
TH +  
InitialTHConsonant +  
AH1 +
BeOdd, data = MyData, family = "binomial")

## This command merely reports the weights that were found:
MyModel

## This one is nicer, because it also gives you a significance test for each weight:
summary(MyModel)

## Print out the model's predictions.
## This next line uses the actual formula for logistic regression to create probabilities, 
## and put the computed probabilities into a new column in MyData.
MyData$Prediction <- exp(predict(MyModel)) / (1 + exp(predict(MyModel)))
## Print the result out as a tab-delimited file.
## The bit with col.names is to compensate for a bug in R; it will otherwise misalign your column names.
write.table(MyData, sep="\t", file = "ModelPredictions.txt", col.names=NA)

## Make a spreadsheet of the grammar.
idx <- coef(summary(MyModel))   
idx          
MyConstraints = round(idx, digits=3)
write.table(MyConstraints, sep="\t", file = "ConstraintsAndWeights.txt", col.names=NA)

